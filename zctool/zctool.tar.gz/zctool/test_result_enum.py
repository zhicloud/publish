#!/usr/bin/python

class TestResultEnum(object):
    success = 0
    fail = 1
    timeout = 2
