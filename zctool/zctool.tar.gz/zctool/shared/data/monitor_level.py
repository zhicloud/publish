#!/usr/bin/python

class MonitorLevel(object):
    system = 0
    server_room = 1
    server_rack = 2
    server = 3
    compute_node = 4
    storage_node = 5
    host = 6
