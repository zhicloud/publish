#!/usr/bin/python

state_initial = 0
state_finish = 0xFFFF

result_success = 0
result_fail = 1
result_any = 2

