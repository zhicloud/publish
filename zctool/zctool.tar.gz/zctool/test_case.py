#!/usr/bin/python

class TestCase(object):
    def __init__(self, name, task_id):
        self.name = name
        self.id = task_id
        self.result = 0
        
